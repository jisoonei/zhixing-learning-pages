import os
os.environ['SDL_VIDEODRIVER'] = 'dummy'
os.environ['SDL_AUDIODRIVER'] = 'dummy'
import pytest
import pygame
from game import Game, Box

@pytest.fixture
def game(tmp_path):
    app = Game(tmp_path / 'score.json')
    app.reset()
    yield app
    pygame.quit()

def test_boundaries(game):
    game.player.x = 759
    game.step(1, 1)
    assert game.player.rect.right <= 800

def test_bullet_limit(game):
    for _ in range(8):
        game.fire()
    assert len(game.bullets) == 4

def test_collision_score(game):
    game.enemies.empty()
    game.enemies.add(Box(100, 100, 32, 24, 'red'))
    game.bullets.add(Box(100, 100, 6, 14, 'white'))
    game.step(0)
    assert game.score == 10
    assert game.level == 2

def test_game_over_and_restart(game):
    game.score, game.high_score = 100, 100
    for _ in range(3):
        game.lose_life()
    assert game.state == 'over'
    game.reset()
    assert (game.score, game.lives, game.level, game.high_score) == (0, 3, 1, 100)

def test_offscreen_cleanup(game):
    game.bullets.add(Box(50, -30, 6, 14, 'white'))
    game.step(0)
    assert len(game.bullets) == 0

def test_corrupt_score(game):
    game.score_path.write_text('{bad', encoding='utf-8')
    assert game.load_score() == 0
    game.high_score = 99
    game.save_score()
    assert game.load_score() == 99
    assert game.score_path.with_suffix('.invalid.json').exists()
