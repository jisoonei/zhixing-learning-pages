"""第 12 章终点。按住方向键移动，松开停止，Esc 退出。"""
import pygame


def move_x(x, direction, speed, seconds, right_limit):
    distance = direction * speed * min(max(seconds, 0.0), 0.05)
    return max(0.0, min(x + distance, right_limit))


def main():
    pygame.init()
    screen = pygame.display.set_mode((800, 600))
    pygame.display.set_caption("Signal Guard - move the player")
    clock = pygame.time.Clock()
    player = pygame.Rect(380, 540, 40, 24)
    x = float(player.x)
    speed = 320
    running = True

    while running:
        seconds = clock.tick(60) / 1000
        for event in pygame.event.get():
            if event.type == pygame.QUIT or (
                event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE
            ):
                running = False
        keys = pygame.key.get_pressed()
        direction = int(keys[pygame.K_RIGHT]) - int(keys[pygame.K_LEFT])
        x = move_x(x, direction, speed, seconds, screen.get_width() - player.width)
        player.x = round(x)
        screen.fill("#142b2b")
        pygame.draw.rect(screen, "#80d9bc", player)
        pygame.display.flip()
    pygame.quit()


if __name__ == "__main__":
    main()
