"""原创练习：信号守卫。左右移动，空格发射，点击或 Enter 开始。"""
from dataclasses import dataclass
from pathlib import Path
import argparse
import json
import os

os.environ.setdefault('PYGAME_HIDE_SUPPORT_PROMPT', '1')
import pygame


@dataclass
class Settings:
    width: int = 800
    height: int = 600
    player_speed: float = 320.0
    bullet_speed: float = 440.0
    enemy_speed: float = 55.0


class Box(pygame.sprite.Sprite):
    def __init__(self, x, y, width, height, color):
        super().__init__()
        self.image = pygame.Surface((width, height), pygame.SRCALPHA)
        self.image.fill(color)
        self.rect = self.image.get_rect(topleft=(x, y))
        self.x, self.y = float(x), float(y)


class Game:
    def __init__(self, score_path=None, *, fullscreen=False):
        pygame.init()
        self.settings = Settings()
        flags = pygame.FULLSCREEN if fullscreen else 0
        self.screen = pygame.display.set_mode((800, 600), flags)
        pygame.display.set_caption('Signal Guard')
        self.clock = pygame.time.Clock()
        self.font = pygame.font.Font(None, 30)
        self.button = pygame.Rect(270, 270, 260, 60)
        self.score_path = score_path or Path.home() / '.zhixing_signal_guard_score.json'
        self.high_score = self.load_score()
        self.reset()
        self.state = 'ready'

    def load_score(self):
        try:
            value = json.loads(self.score_path.read_text(encoding='utf-8'))['high_score']
            return value if type(value) is int and value >= 0 else 0
        except (OSError, ValueError, KeyError, TypeError):
            return 0

    def save_score(self):
        # 只写这个游戏自己的成绩文件；损坏的旧文件留副本供检查。
        try:
            if self.score_path.exists():
                try:
                    old = json.loads(self.score_path.read_text(encoding='utf-8'))
                    if not isinstance(old, dict) or type(old.get('high_score')) is not int:
                        raise ValueError('invalid score')
                except (ValueError, UnicodeError):
                    backup = self.score_path.with_suffix('.invalid.json')
                    if not backup.exists():
                        backup.write_bytes(self.score_path.read_bytes())
            temp = self.score_path.with_suffix('.tmp')
            temp.write_text(json.dumps({'high_score': self.high_score}), encoding='utf-8')
            temp.replace(self.score_path)
        except OSError as exc:
            print(f'成绩保存失败：{exc}')

    def reset(self):
        self.score, self.lives, self.level = 0, 3, 1
        self.player = Box(380, 540, 40, 24, '#80d9bc')
        self.bullets = pygame.sprite.Group()
        self.enemies = pygame.sprite.Group()
        self.direction = 1
        self.spawn_wave()
        self.state = 'playing'

    def spawn_wave(self):
        self.enemies.empty()
        self.direction = 1
        for row in range(3):
            for column in range(8):
                self.enemies.add(Box(70 + column * 70, 65 + row * 45, 32, 24, '#efaa78'))

    def fire(self):
        if self.state == 'playing' and len(self.bullets) < 4:
            self.bullets.add(Box(self.player.rect.centerx - 3, self.player.rect.top, 6, 14, '#e9f1de'))

    def lose_life(self):
        self.lives -= 1
        self.bullets.empty()
        if self.lives <= 0:
            self.state = 'over'
            self.save_score()
        else:
            self.player.x = 380.0
            self.player.rect.x = 380
            self.spawn_wave()

    def step(self, dt, movement=0):
        if self.state != 'playing':
            return
        dt = max(0.0, min(dt, 0.05))  # 限制停顿后的单次跳跃
        self.player.x = max(0.0, min(760.0, self.player.x + movement * self.settings.player_speed * dt))
        self.player.rect.x = round(self.player.x)
        for bullet in list(self.bullets):
            bullet.y -= self.settings.bullet_speed * dt
            bullet.rect.y = round(bullet.y)
            if bullet.rect.bottom < 0:
                bullet.kill()
        speed = self.settings.enemy_speed * min(1 + (self.level - 1) * 0.2, 3)
        edge = any(e.x + self.direction * speed * dt < 0 or
                   e.x + self.direction * speed * dt + e.rect.width > 800 for e in self.enemies)
        if edge:
            self.direction *= -1
            for enemy in self.enemies:
                enemy.y += 22
        for enemy in self.enemies:
            enemy.x += self.direction * speed * dt
            enemy.rect.topleft = round(enemy.x), round(enemy.y)
        hits = pygame.sprite.groupcollide(self.bullets, self.enemies, True, True)
        # 同一目标可能与两颗弹同时重叠，按对象去重后计分。
        destroyed = {enemy for group in hits.values() for enemy in group}
        self.score += len(destroyed) * 10 * self.level
        self.high_score = max(self.high_score, self.score)
        if pygame.sprite.spritecollideany(self.player, self.enemies) or any(e.rect.bottom >= 600 for e in self.enemies):
            self.lose_life()
        elif not self.enemies:
            self.level += 1
            self.bullets.empty()
            self.spawn_wave()

    def draw(self):
        self.screen.fill('#142b2b')
        self.screen.blit(self.player.image, self.player.rect)
        self.enemies.draw(self.screen)
        self.bullets.draw(self.screen)
        label = f'Score {self.score:,}   Best {self.high_score:,}   Lives {self.lives}   Level {self.level}'
        self.screen.blit(self.font.render(label, True, '#e9f1de'), (20, 15))
        if self.state != 'playing':
            pygame.draw.rect(self.screen, '#356d61', self.button, border_radius=12)
            self.screen.blit(self.font.render('Enter / Click to play', True, 'white'), (292, 287))
        pygame.mouse.set_visible(self.state != 'playing')
        pygame.display.flip()

    def run(self, max_frames=None):
        running, frames = True, 0
        while running:
            dt = self.clock.tick(60) / 1000
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                if event.type == pygame.KEYDOWN:
                    if event.key in (pygame.K_q, pygame.K_ESCAPE):
                        running = False
                    elif event.key == pygame.K_SPACE:
                        self.fire()
                    elif event.key == pygame.K_RETURN and self.state != 'playing':
                        self.reset()
                if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    if self.state != 'playing' and self.button.collidepoint(event.pos):
                        self.reset()
            keys = pygame.key.get_pressed()
            self.step(dt, int(keys[pygame.K_RIGHT]) - int(keys[pygame.K_LEFT]))
            self.draw()
            frames += 1
            if max_frames and frames >= max_frames:
                running = False
        self.save_score()
        pygame.quit()


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--frames', type=int)
    parser.add_argument('--fullscreen', action='store_true')
    args = parser.parse_args()
    Game(fullscreen=args.fullscreen).run(args.frames)
