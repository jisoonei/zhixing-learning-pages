"""第 12 章弹体实验。调用原游戏逻辑，在终端核对每一步。"""
from pathlib import Path
from tempfile import TemporaryDirectory
import os


def inspect_bullets():
    os.environ["SDL_VIDEODRIVER"] = "dummy"
    os.environ["SDL_AUDIODRIVER"] = "dummy"
    from game import Game, pygame

    with TemporaryDirectory() as folder:
        game = Game(Path(folder) / "score.json")
        try:
            game.fire()
            assert len(game.bullets) == 0
            game.reset()
            for _ in range(5):
                game.fire()
            first = game.bullets.sprites()[0]
            print("连续发射 5 次，弹体数", len(game.bullets))
            assert len(game.bullets) == 4
            assert first.rect.midtop == game.player.rect.midtop

            print("起点", first.rect.topleft)
            game.step(0.05)
            print("一帧后", first.rect.topleft)
            assert first.rect.topleft == (397, 518)

            # 只把第一颗放到边界。用 0 秒检查清理条件，其他三颗留在原位。
            first.y = -float(first.rect.height)
            game.step(0)
            print("底边等于 0", len(game.bullets))
            assert first in game.bullets
            first.y -= 1
            game.step(0)
            print("底边小于 0", len(game.bullets))
            assert first not in game.bullets and len(game.bullets) == 3
            game.fire()
            print("再次发射", len(game.bullets))
            assert len(game.bullets) == 4
        finally:
            pygame.quit()


if __name__ == "__main__":
    inspect_bullets()
