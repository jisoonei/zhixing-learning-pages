import pytest

from move_player import move_x


@pytest.mark.parametrize("x,direction,speed,seconds,expected", [
    (380, 1, 320, 0.05, 396),
    (380, -1, 320, 0.05, 364),
    (380, 0, 320, 0.05, 380),
    (755, 1, 320, 0.05, 760),
    (5, -1, 320, 0.05, 0),
    (380, 1, 320, 1.0, 396),
    (380, 1, 320, 0.0, 380),
    (380, 1, 160, 0.05, 388),
])
def test_one_frame(x, direction, speed, seconds, expected):
    assert move_x(x, direction, speed, seconds, 760) == expected


def test_fractional_position_survives_between_frames():
    x = 380.0
    for _ in range(4):
        x = move_x(x, 1, 10, 0.025, 760)
    assert x == 381.0
