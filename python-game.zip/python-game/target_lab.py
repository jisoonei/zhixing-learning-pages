"""第 13 章。使用原游戏检查目标阵列、折返、命中与波次。"""
from pathlib import Path
from tempfile import TemporaryDirectory
import os


def inspect_targets():
    os.environ["SDL_VIDEODRIVER"] = "dummy"
    os.environ["SDL_AUDIODRIVER"] = "dummy"
    from game import Game, Box, pygame

    with TemporaryDirectory() as folder:
        game = Game(Path(folder) / "score.json")
        try:
            game.reset()
            targets = game.enemies.sprites()
            assert len(targets) == 24
            assert targets[0].rect.topleft == (70, 65)
            assert targets[-1].rect.topleft == (560, 155)
            print("阵列", len(targets), targets[0].rect.topleft, targets[-1].rect.topleft)

            # 右侧目标放在临界位置，观察整队一起折返。
            targets[-1].x = 767.0
            old_y = [target.y for target in targets]
            game.step(0.05)
            assert game.direction == -1
            assert all(target.y == y + 22 for target, y in zip(targets, old_y))
            print("折返", game.direction, targets[0].y, targets[-1].y)

            game.reset()
            game.enemies.empty()
            game.enemies.add(Box(100, 100, 32, 24, "red"), Box(300, 100, 32, 24, "red"))
            # 弹体右边恰好贴着目标左边，尚未重叠。
            bullet = Box(94, 100, 6, 14, "white")
            game.bullets.add(bullet)
            game.step(0)
            assert len(game.enemies) == 2 and game.score == 0
            print("贴边", len(game.enemies), game.score)
            bullet.x = 95
            bullet.rect.x = 95
            game.step(0)
            assert len(game.enemies) == 1 and len(game.bullets) == 0 and game.score == 10
            print("重叠一像素", len(game.enemies), len(game.bullets), game.score)
            game.step(0)
            assert game.score == 10
            print("再检查一次", game.score)

            game.bullets.add(Box(300, 100, 6, 14, "white"))
            game.step(0)
            assert game.level == 2 and len(game.enemies) == 24 and game.score == 20
            print("最后一个命中", game.level, len(game.enemies), game.score)

            # 分别复现接触角色和越过底边，再观察耗尽生命。
            game.reset()
            game.enemies.empty()
            game.enemies.add(Box(380, 540, 32, 24, "red"))
            game.step(0)
            assert game.lives == 2 and len(game.enemies) == 24
            print("接触角色", game.lives)
            for expected in (1, 0):
                game.enemies.empty()
                game.enemies.add(Box(100, 576, 32, 24, "red"))
                game.step(0)
                assert game.lives == expected
            assert game.state == "over"
            print("生命耗尽", game.lives, game.state)
        finally:
            pygame.quit()


if __name__ == "__main__":
    inspect_targets()
