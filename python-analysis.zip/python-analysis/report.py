"""原创项目：校园事件数据图册。默认完全离线，输出到新目录。"""
import argparse
import csv
from datetime import date
from pathlib import Path
import json
from random import Random


def load_daily(path):
    records, rejected = [], []
    with Path(path).open(encoding='utf-8-sig', newline='') as stream:
        reader = csv.DictReader(stream)
        if not {'date', 'low', 'high'} <= set(reader.fieldnames or []):
            raise ValueError('缺少 date/low/high 表头')
        for line, row in enumerate(reader, 2):
            try:
                day = date.fromisoformat(row['date'])
                low, high = int(row['low']), int(row['high'])
                if not 0 <= low <= high:
                    raise ValueError('要求 0 <= low <= high')
            except (ValueError, TypeError, KeyError) as exc:
                rejected.append({'line': line, 'reason': str(exc), 'raw': row})
            else:
                records.append((day, low, high))
    records.sort(key=lambda r: r[0])
    if len({r[0] for r in records}) != len(records):
        raise ValueError('日期重复：请先确定合并规则')
    return records, rejected


def walk(seed=7, count=500):
    if count < 1:
        raise ValueError('count 至少为 1')
    rng = Random(seed)
    points = [(0, 0)]
    while len(points) < count:
        dx, dy = rng.choice([-1, 0, 1]), rng.choice([-1, 0, 1])
        if dx or dy:
            x, y = points[-1]
            points.append((x + dx, y + dy))
    return points


def dice(seed=7, count=1000, sides=(6, 8)):
    if count < 1 or len(sides) != 2 or any(type(n) is not int or n < 1 for n in sides):
        raise ValueError('需要两颗合法骰子和正样本量')
    rng = Random(seed)
    counts = {total: 0 for total in range(2, sum(sides) + 1)}
    for _ in range(count):
        counts[rng.randint(1, sides[0]) + rng.randint(1, sides[1])] += 1
    return counts


def load_places(path):
    payload = json.loads(Path(path).read_text(encoding='utf-8'))
    if payload.get('type') != 'FeatureCollection':
        raise ValueError('需要 FeatureCollection')
    accepted, rejected = [], []
    for item in payload.get('features', []):
        try:
            geometry = item['geometry']
            if geometry['type'] != 'Point':
                raise ValueError('仅接受 Point')
            lon, lat = geometry['coordinates'][:2]
            if type(lon) not in (int, float) or type(lat) not in (int, float):
                raise ValueError('经纬度必须是数值')
            if not -180 <= lon <= 180 or not -90 <= lat <= 90:
                raise ValueError('经纬度越界')
            properties = item['properties']
            count = properties['count']
            if type(count) is not int or count < 0:
                raise ValueError('count 必须是非负整数')
            accepted.append(dict(lon=lon, lat=lat, name=str(properties['name']), count=count))
        except (KeyError, TypeError, ValueError) as exc:
            rejected.append(str(exc))
    return accepted, rejected


def fetch_repositories(session=None):
    # 只有显式 --live 才联网，默认测试使用本地快照。
    import requests
    client = session or requests
    response = client.get('https://api.github.com/search/repositories',
        params={'q': 'language:python', 'sort': 'stars', 'per_page': 5},
        headers={'Accept': 'application/vnd.github+json'}, timeout=(5, 20))
    response.raise_for_status()
    return response.json()


def repository_rows(payload):
    items = payload.get('items')
    if not isinstance(items, list):
        raise ValueError('API 缺少 items 数组')
    result = []
    for item in items:
        stars = item.get('stargazers_count')
        if type(stars) is not int or stars < 0:
            raise ValueError('API stars 不是非负整数')
        result.append((str(item['full_name']), stars, item.get('description') or '暂无说明'))
    return result


def build(output, *, live=False):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    import plotly.graph_objects as go
    base = Path(__file__).resolve().parent
    output = Path(output)
    output.mkdir(parents=True, exist_ok=False)  # 保留旧报告；换一个新目录名重跑
    records, rejected = load_daily(base / 'daily.csv')
    days, lows, highs = zip(*records)
    fig, ax = plt.subplots(layout='constrained')
    ax.plot(days, highs, label='High', color='#277968')
    ax.plot(days, lows, label='Low', color='#b27d44')
    ax.fill_between(days, lows, highs, alpha=0.15, color='#277968')
    ax.set(title='Synthetic daily interaction range', xlabel='Date', ylabel='Likes')
    ax.legend()
    fig.autofmt_xdate()
    fig.savefig(output / 'daily.png', dpi=160)
    plt.close(fig)

    points = walk()
    x, y = zip(*points)
    fig, ax = plt.subplots(layout='constrained')
    cloud = ax.scatter(x, y, c=range(len(points)), cmap='viridis', s=9)
    ax.scatter([x[0], x[-1]], [y[0], y[-1]], c=['red', 'orange'], s=55)
    ax.set_aspect('equal', adjustable='datalim')
    ax.set_title('Random walk: seed=7, 500 positions')
    fig.colorbar(cloud, ax=ax, label='Step')
    fig.savefig(output / 'walk.png', dpi=160)
    plt.close(fig)

    counts = dice()
    chart = go.Figure(go.Bar(x=list(counts), y=list(counts.values())))
    chart.update_layout(title='Sum of d6 + d8: simulation', xaxis_title='Sum', yaxis_title='Frequency')
    chart.write_html(output / 'dice.html', include_plotlyjs=True)

    places, map_rejected = load_places(base / 'places.geojson')
    # scattergeo 的底图可能额外请求地理资源，离线包改用经纬度坐标散点。
    chart = go.Figure(go.Scatter(x=[p['lon'] for p in places], y=[p['lat'] for p in places],
        mode='markers', text=[p['name'] for p in places],
        marker=dict(size=[8 + p['count'] ** 0.5 for p in places],
                    color=[p['count'] for p in places], colorscale='Viridis', showscale=True),
        hovertemplate='%{text}<br>lon=%{x}<br>lat=%{y}<extra></extra>'))
    chart.update_layout(title='Synthetic locations (coordinate plot, no map projection)',
        xaxis_title='Longitude', yaxis_title='Latitude')
    chart.write_html(output / 'places.html', include_plotlyjs=True)

    payload = fetch_repositories() if live else json.loads((base / 'api_snapshot.json').read_text(encoding='utf-8'))
    repositories = repository_rows(payload)
    chart = go.Figure(go.Bar(x=[r[0] for r in repositories], y=[r[1] for r in repositories],
        customdata=[r[2] for r in repositories], hovertemplate='%{x}<br>%{y} stars<br>%{customdata}<extra></extra>'))
    chart.update_layout(title='GitHub live query' if live else 'Synthetic API fixture (not a live ranking)')
    chart.write_html(output / 'repositories.html', include_plotlyjs=True)
    metadata = {'source': 'GitHub live' if live else 'synthetic fixtures', 'seed': 7,
        'daily_rows': len(records), 'rejected': rejected, 'map_rejected': map_rejected}
    (output / 'audit.json').write_text(json.dumps(metadata, ensure_ascii=False, indent=2), encoding='utf-8')
    print(f'有效日记录 {len(records)}；拒绝 {len(rejected)}；位置拒绝 {len(map_rejected)}')
    print('已生成 daily.png、walk.png、dice.html、places.html、repositories.html、audit.json')


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', default='output')
    parser.add_argument('--live', action='store_true')
    args = parser.parse_args()
    build(args.output, live=args.live)
