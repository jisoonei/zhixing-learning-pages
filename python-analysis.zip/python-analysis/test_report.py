import json
from pathlib import Path
import pytest
from report import load_daily, walk, dice, load_places, repository_rows, fetch_repositories

BASE = Path(__file__).parent

def test_aligned_dates():
    rows, rejected = load_daily(BASE / 'daily.csv')
    assert len(rows) == 4 and len(rejected) == 2
    assert [row[0].day for row in rows] == [1, 2, 3, 5]

def test_duplicate_dates(tmp_path):
    path = tmp_path / 'duplicate.csv'
    path.write_text('date,low,high\n2026-01-01,0,1\n2026-01-01,0,2\n')
    with pytest.raises(ValueError, match='日期重复'):
        load_daily(path)

def test_random_reproducible():
    assert walk(7) == walk(7)
    assert len(walk(7, 5)) == 5

def test_dice_contract():
    result = dice(count=200)
    assert sum(result.values()) == 200
    assert min(result) == 2 and max(result) == 14

def test_coordinates():
    good, bad = load_places(BASE / 'places.geojson')
    assert len(good) == 2 and len(bad) == 1

def test_api_schema():
    with pytest.raises(ValueError):
        repository_rows({'items': [{'stargazers_count': 'bad'}]})

def test_request_boundary():
    class Response:
        def raise_for_status(self):
            self.checked = True
        def json(self):
            assert self.checked
            return {'items': []}
    class FakeSession:
        def get(self, url, **kwargs):
            assert kwargs['timeout'] == (5, 20)
            assert kwargs['params']['per_page'] == 5
            return Response()
    assert fetch_repositories(FakeSession()) == {'items': []}
