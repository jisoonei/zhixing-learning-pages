"""教学快照导入：仅使用 Python 标准库。"""
import csv
import sqlite3
from pathlib import Path
BASE = Path(__file__).resolve().parent
EVENTS = [(1, '校园音乐节'), (2, '科技展'), (3, '读书会')]

def normalize(row):
    post_id = int(row['post_id'])
    event_id = int(row['event_id'])
    likes = int(row['likes'])
    if post_id <= 0 or event_id not in {e[0] for e in EVENTS} or likes < 0:
        raise ValueError('ID、事件编号或点赞数不合法')
    return (post_id, event_id, likes, row['text'].strip())

def load_records(path):
    accepted, rejected, seen = [], [], set()
    with path.open(encoding='utf-8-sig', newline='') as f:
        for line, row in enumerate(csv.DictReader(f), 2):
            try:
                record = normalize(row)
                if record[0] in seen:
                    raise ValueError('重复 post_id（保留首条有效记录）')
            except (ValueError, KeyError, TypeError) as error:
                rejected.append((line, row.get('post_id', ''), str(error)))
                continue
            seen.add(record[0])
            accepted.append(record)
    return accepted, rejected

def write_csv(name, headers, records):
    with (BASE / name).open('w', encoding='utf-8-sig', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(headers)
        writer.writerows(records)

def main():
    accepted, rejected = load_records(BASE / 'raw_posts.csv')
    con = sqlite3.connect(BASE / 'demo.sqlite3')
    try:
        con.execute('PRAGMA foreign_keys=ON')
        con.execute('CREATE TABLE IF NOT EXISTS events(id INTEGER PRIMARY KEY, title TEXT NOT NULL)')
        con.execute('''CREATE TABLE IF NOT EXISTS posts(
            id INTEGER PRIMARY KEY,
            event_id INTEGER NOT NULL REFERENCES events(id),
            likes INTEGER NOT NULL CHECK(likes >= 0),
            text TEXT NOT NULL)''')
        with con:
            con.executemany('INSERT OR IGNORE INTO events VALUES (?, ?)', EVENTS)
            con.execute('DELETE FROM posts')
            con.executemany('INSERT INTO posts VALUES (?, ?, ?, ?)', accepted)
        report = con.execute('''SELECT e.id, e.title, COUNT(p.id), COALESCE(SUM(p.likes), 0)
            FROM events e LEFT JOIN posts p ON p.event_id=e.id
            GROUP BY e.id,e.title ORDER BY e.id''').fetchall()
    finally:
        con.close()
    write_csv('report.csv', ['event_id', 'title', 'post_count', 'total_likes'], report)
    write_csv('rejected.csv', ['source_line', 'post_id', 'reason'], rejected)
    print(f'有效 {len(accepted)} 条，拒绝 {len(rejected)} 条')
    for row in report:
        print(f'{row[1]}：{row[2]} 条，{row[3]} 赞')

if __name__ == '__main__':
    main()
