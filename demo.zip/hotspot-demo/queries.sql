-- SQLite 项目查询；先运行 main.py 生成数据库。
SELECT * FROM posts WHERE likes >= 10 ORDER BY likes DESC, id;
SELECT event_id, COUNT(*) AS n, SUM(likes) AS total
FROM posts WHERE likes >= 10 GROUP BY event_id HAVING COUNT(*) >= 2 ORDER BY total DESC;
SELECT e.id,e.title,COUNT(p.id) AS n,COALESCE(SUM(p.likes),0) AS total
FROM events e LEFT JOIN posts p ON e.id=p.event_id
GROUP BY e.id,e.title ORDER BY e.id;
WITH ranked AS (
 SELECT id,event_id,likes,ROW_NUMBER() OVER(PARTITION BY event_id ORDER BY likes DESC,id) AS rn
 FROM posts
) SELECT * FROM ranked WHERE rn <= 2;
