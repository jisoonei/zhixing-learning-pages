# 热点事件观察站 · 第一阶段参考实现

所有数据为合成教学样本。本项目不依赖第三方 Python 包，使用标准库 sqlite3（若发行版未包含，请安装带 SQLite 支持的 Python）。

## 运行
1. 解压整个目录，不要只打开 main.py。
2. 进入目录，在终端执行 `py main.py`（Windows）或 `python3 main.py`（macOS / Linux）。建议 Python 3.14。
3. 输出 report.csv、rejected.csv、demo.sqlite3。路径基于脚本所在目录。
4. 连续运行两次，确认 5 条有效记录不翻倍。

## 预期
输入 7 行，5 行有效、2 行拒绝；音乐节 3 条 45 赞，科技展 2 条 20 赞，读书会 0 条 0 赞。

## 实现边界
每次运行事务内替换全部 posts，这是本地快照导入，不适合直接用于生产增量更新。数据校验失败进入 rejected.csv；数据库约束失败会使本批数据库修改回滚。CSV 报表导出发生在提交之后，不与数据库写入组成跨文件事务；导出失败可重新运行。

## 分阶段练习
- 章节 1–5：不用数据库，手写筛选、去重与按事件求和。
- 章节 6–7：补出 normalize 和 load_records，解释两个拒绝原因。
- 章节 8–13：在 SQLite 客户端执行 queries.sql；MySQL 讲解对照网站文档，不能混用 START TRANSACTION、PRAGMA 等方言。
- 章节 14–15：不看答案独立完成 main.py；增加一条有效记录后手算并核对。
- 进一步：用临时数据库验证插入重复主键时整批回滚；给清洗函数补空值、负数、未知事件边界测试。

## 方言差异
SQLite 在 Python sqlite3 中使用 ? 参数占位符；MySQL 的具体占位符取决于驱动，常见为 %s。SQLite 外键检查需每连接启用。MySQL 使用 InnoDB 并显式 START TRANSACTION；其 DDL 的隐式提交语义不可与 SQLite 混同。主键自增、日期函数、类型约束都需要迁移时复核。
