"""沙盒限定、只新增的幂等导入：不修改或删除已存在的博文。"""
import csv
import os
from contextlib import closing
from pathlib import Path

BASE = Path(__file__).resolve().parent
SANDBOX = 'Zhixing_Sandbox'
MAX_INT = 2_147_483_647


def load_records(path):
    accepted, rejected, seen = [], [], set()
    with path.open(encoding='utf-8-sig', newline='') as source:
        reader = csv.DictReader(source)
        if not {'post_id', 'event_id', 'likes', 'text'} <= set(reader.fieldnames or []):
            raise ValueError('CSV 缺少必要表头；本次不连接数据库。')
        for line, row in enumerate(reader, 2):
            try:
                post_id, event_id, likes = (int(row[k]) for k in ('post_id', 'event_id', 'likes'))
                if not (0 < post_id <= MAX_INT and event_id in {1, 2, 3} and 0 <= likes <= MAX_INT):
                    raise ValueError('编号/点赞超出 SQL int 范围，或事件编号不合法')
                text = row['text'].strip()
                # NVARCHAR(500) 按 UTF-16 代码单元计长，emoji 可能占两个单元。
                if len(text.encode('utf-16-le')) // 2 > 500:
                    raise ValueError('正文超过 NVARCHAR(500) 容量')
                if post_id in seen:
                    raise ValueError('重复 ID；保留首条有效记录')
            except (ValueError, TypeError, AttributeError, UnicodeError) as error:
                rejected.append((line, row.get('post_id', ''), str(error)))
                continue
            seen.add(post_id)
            accepted.append((post_id, event_id, likes, text))
    return accepted, rejected


def assert_sandbox(cursor):
    # 验证服务器实际返回的数据库，而不是只检查连接字符串。
    row = cursor.execute('SELECT DB_NAME()').fetchone()
    if not row or row[0] != SANDBOX:
        raise RuntimeError('拒绝导入：连接目标必须为 Zhixing_Sandbox。')
    marker = cursor.execute("""SELECT CONVERT(nvarchar(128), value)
        FROM sys.extended_properties
        WHERE class = 0 AND name = N'Zhixing_Workbook'""").fetchone()
    if not marker or marker[0] != 'sandbox-v1':
        raise RuntimeError('拒绝导入：缺少手册沙盒标记，请先执行 setup.sql。')


def import_records(connection, records):
    """connection 必须使用 autocommit=False；异常整批回滚。"""
    if connection.autocommit:
        raise RuntimeError('拒绝导入：需要 autocommit=False。')
    try:
        cursor = connection.cursor()
        assert_sandbox(cursor)  # 任何写操作之前完成双重校验
        cursor.execute('SET XACT_ABORT ON; SET NOCOUNT ON;')
        # 显式开始事务，应用锁作用于事务；同一导入器并发运行会串行化。
        cursor.execute('IF @@TRANCOUNT = 0 BEGIN TRANSACTION;')
        cursor.execute("""DECLARE @r int;
            EXEC @r = sys.sp_getapplock
                @Resource=N'Zhixing_Workbook_Write', @LockMode=N'Exclusive',
                @LockOwner=N'Transaction', @LockTimeout=10000;
            IF @r < 0 THROW 51002, N'无法取得沙盒写入锁。', 1;""")
        cursor.execute('''CREATE TABLE #Incoming (
            id int PRIMARY KEY, event_id int NOT NULL,
            likes int NOT NULL CHECK (likes >= 0), [text] nvarchar(500) NOT NULL
        );''')
        if records:  # 空文件不调用 executemany，也不修改目标表
            cursor.executemany('INSERT INTO #Incoming (id,event_id,likes,[text]) VALUES (?,?,?,?)', records)
        existing = {
            row[0]: tuple(row[1:])
            for row in cursor.execute('''SELECT p.id,p.event_id,p.likes,p.[text]
                FROM dbo.posts AS p WITH (UPDLOCK,HOLDLOCK)
                JOIN #Incoming AS s ON s.id=p.id''').fetchall()
        }
        conflicts = [(r[0], '相同 ID 已有不同内容；保留数据库原值')
                     for r in records if r[0] in existing and existing[r[0]] != tuple(r[1:])]
        unchanged = sum(r[0] in existing and existing[r[0]] == tuple(r[1:]) for r in records)
        # 不使用 UPDATE/DELETE/MERGE 的匹配修改分支：只插入尚不存在的 id。
        cursor.execute('''INSERT INTO dbo.posts (id,event_id,likes,[text])
            SELECT s.id,s.event_id,s.likes,s.[text] FROM #Incoming AS s
            WHERE NOT EXISTS (
                SELECT 1 FROM dbo.posts AS p WITH (UPDLOCK,HOLDLOCK) WHERE p.id=s.id
            );''')
        report = [tuple(row) for row in cursor.execute('''SELECT e.id,e.title,COUNT(p.id),
                COALESCE(SUM(CONVERT(bigint,p.likes)),0)
            FROM dbo.events AS e LEFT JOIN dbo.posts AS p ON p.event_id=e.id
            GROUP BY e.id,e.title ORDER BY e.id''').fetchall()]
        cursor.execute('DROP TABLE #Incoming;')  # 仅释放会话临时表
        connection.commit()
        return len(records) - len(existing), unchanged, conflicts, report
    except Exception:
        connection.rollback()
        raise


def write_csv(filename, headers, rows):
    with (BASE / filename).open('w', encoding='utf-8-sig', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(headers)
        writer.writerows(rows)


def main():
    import pyodbc  # 安装 pyodbc 和 Microsoft ODBC Driver 后才运行连接部分
    accepted, rejected = load_records(BASE / 'raw_posts.csv')
    with closing(pyodbc.connect(os.environ['SQLSERVER_CONNECTION_STRING'], autocommit=False)) as connection:
        inserted, unchanged, conflicts, report = import_records(connection, accepted)
    write_csv('report.csv', ['event_id', 'title', 'post_count', 'total_likes'], report)
    write_csv('rejected.csv', ['source_line', 'post_id', 'reason'], rejected)
    write_csv('conflicts.csv', ['post_id', 'reason'], conflicts)
    print(f'有效 {len(accepted)}，拒绝 {len(rejected)}；新增 {inserted}，相同跳过 {unchanged}，冲突 {len(conflicts)}')
    for _, title, count, likes in report:
        print(f'{title}：{count} 条，{likes} 赞')


if __name__ == '__main__':
    main()
