﻿-- 前提：先完整执行 sqlserver-setup.sql；以下为单批次，不要拆开执行。
USE [Zhixing_Sandbox];
IF DB_NAME() <> N'Zhixing_Sandbox'
    THROW 51000, N'拒绝操作非沙盒数据库。', 1;
IF NOT EXISTS (SELECT 1 FROM sys.extended_properties
    WHERE class = 0 AND name = N'Zhixing_Workbook'
      AND CONVERT(nvarchar(128), value) = N'sandbox-v1')
    THROW 51001, N'缺少手册沙盒标记，请先运行初始化脚本。', 1;
IF @@TRANCOUNT <> 0
    THROW 51003, N'请在无未提交事务的新查询窗口运行。', 1;
SET IMPLICIT_TRANSACTIONS OFF;
SET XACT_ABORT ON;

CREATE TABLE #EventExercise (id int PRIMARY KEY, title nvarchar(100) NOT NULL);
CREATE TABLE #PostExercise (id int PRIMARY KEY, event_id int NOT NULL,
    likes int NOT NULL, [text] nvarchar(500) NOT NULL);
BEGIN TRY
    BEGIN TRANSACTION;
    INSERT INTO #EventExercise (id, title) VALUES (9, N'测试事件');
    INSERT INTO #PostExercise (id, event_id, likes, [text]) VALUES (90, 9, 12, N'测试博文');
    ROLLBACK TRANSACTION;
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
    THROW;
END CATCH;
SELECT * FROM #EventExercise;
SELECT * FROM #PostExercise;
DROP TABLE #PostExercise;
DROP TABLE #EventExercise;
