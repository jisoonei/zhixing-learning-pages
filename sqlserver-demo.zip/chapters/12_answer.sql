﻿-- 前提：先完整执行 sqlserver-setup.sql；以下为单批次，不要拆开执行。
USE [Zhixing_Sandbox];
IF DB_NAME() <> N'Zhixing_Sandbox'
    THROW 51000, N'拒绝操作非沙盒数据库。', 1;
IF NOT EXISTS (SELECT 1 FROM sys.extended_properties
    WHERE class = 0 AND name = N'Zhixing_Workbook'
      AND CONVERT(nvarchar(128), value) = N'sandbox-v1')
    THROW 51001, N'缺少手册沙盒标记，请先运行初始化脚本。', 1;
IF @@TRANCOUNT <> 0
    THROW 51003, N'请在无未提交事务的新查询窗口运行。', 1;
SET IMPLICIT_TRANSACTIONS OFF;
SET XACT_ABORT ON;

DECLARE @start_date date=DATEFROMPARTS(2026,1,1);
SELECT DATEADD(day,1,@start_date) AS end_date;
-- 时间字段尚未加入项目。用 VALUES 构造独立数据演示半开区间。
SELECT v.created_at FROM (VALUES
 (CONVERT(datetime2,'2026-01-01T00:00:00',126)),
 (CONVERT(datetime2,'2026-02-01T00:00:00',126))
) AS v(created_at)
WHERE v.created_at>=@start_date AND v.created_at<DATEADD(month,1,@start_date);
