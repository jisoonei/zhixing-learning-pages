﻿-- 前提：先完整执行 sqlserver-setup.sql；以下为单批次，不要拆开执行。
USE [Zhixing_Sandbox];
IF DB_NAME() <> N'Zhixing_Sandbox'
    THROW 51000, N'拒绝操作非沙盒数据库。', 1;
IF NOT EXISTS (SELECT 1 FROM sys.extended_properties
    WHERE class = 0 AND name = N'Zhixing_Workbook'
      AND CONVERT(nvarchar(128), value) = N'sandbox-v1')
    THROW 51001, N'缺少手册沙盒标记，请先运行初始化脚本。', 1;
IF @@TRANCOUNT <> 0
    THROW 51003, N'请在无未提交事务的新查询窗口运行。', 1;
SET IMPLICIT_TRANSACTIONS OFF;
SET XACT_ABORT ON;

IF NOT EXISTS (SELECT 1 FROM sys.indexes
    WHERE object_id = OBJECT_ID(N'dbo.posts') AND name = N'ix_posts_event_id')
    CREATE INDEX ix_posts_event_id ON dbo.posts(event_id);
SELECT id, likes FROM dbo.posts WHERE event_id = 1 ORDER BY id;
