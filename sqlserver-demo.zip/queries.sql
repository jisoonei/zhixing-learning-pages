﻿-- 前提：先完整执行 sqlserver-setup.sql；以下为单批次，不要拆开执行。
USE [Zhixing_Sandbox];
IF DB_NAME() <> N'Zhixing_Sandbox'
    THROW 51000, N'拒绝操作非沙盒数据库。', 1;
IF NOT EXISTS (SELECT 1 FROM sys.extended_properties
    WHERE class = 0 AND name = N'Zhixing_Workbook'
      AND CONVERT(nvarchar(128), value) = N'sandbox-v1')
    THROW 51001, N'缺少手册沙盒标记，请先运行初始化脚本。', 1;
IF @@TRANCOUNT <> 0
    THROW 51003, N'请在无未提交事务的新查询窗口运行。', 1;
SET IMPLICIT_TRANSACTIONS OFF;
SET XACT_ABORT ON;

-- 在已经执行 setup.sql 的示例数据库中逐条运行。
-- 1. 每个事件的博文数和点赞数，包括没有博文的事件。
SELECT e.id, e.title, COUNT(p.id) AS post_count,
       COALESCE(SUM(CONVERT(bigint,p.likes)), 0) AS total_likes
FROM dbo.events AS e LEFT JOIN dbo.posts AS p ON p.event_id = e.id
GROUP BY e.id, e.title ORDER BY e.id;

-- 2. 每个事件点赞最高的两条，按 id 处理并列。
;WITH ranked AS (
    SELECT p.id, p.event_id, p.likes, p.[text],
           ROW_NUMBER() OVER (PARTITION BY p.event_id ORDER BY p.likes DESC, p.id) AS rn
    FROM dbo.posts AS p
)
SELECT id, event_id, likes, [text], rn FROM ranked WHERE rn <= 2 ORDER BY event_id, rn;

-- 3. 查询没有博文的事件。
SELECT e.id, e.title FROM dbo.events AS e
WHERE NOT EXISTS (SELECT 1 FROM dbo.posts AS p WHERE p.event_id = e.id)
ORDER BY e.id;
