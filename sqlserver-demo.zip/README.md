# 热点事件观察站 · SQL Server 安全版

## 安全边界

- SQL Server 2012+，数据库兼容级别 110+；不将 Azure SQL Database 当成本地 SQL Server。
- 所有建表和样本数据操作固定在 `Zhixing_Sandbox`；不操作 master 中的业务表，也不自动沿用当前选中的业务数据库。
- setup.sql 仅为自己新建的数据库设置 `Zhixing_Workbook=sandbox-v1` 标记。已有同名但没有标记的数据库会停止处理（包括首次创建后、写入标记前意外中断的情况）；不要给不明数据库强行补标记或删除它。请让管理员核查同名冲突。
- Python 同时检查服务器实际返回的 DB_NAME() 和标记。连接到 master、其他库或无标记库时，在任何写入之前拒绝执行。
- 导入只新增缺失 id：相同 ID、相同内容跳过；相同 ID、不同内容记录到 conflicts.csv，保留数据库原值。输入文件少了一行或变为空文件，都不会删除已有数据库记录。
- 初始化、导入均不做 UPDATE/DELETE/TRUNCATE 或删除缺失行的 MERGE。应用锁与 UPDLOCK/HOLDLOCK 用于同一沙盒写入协调；操作失败整批回滚。此机制不代替正式生产库权限、备份及并发负载测试。

## 运行步骤

1. 在 SSMS 的**新查询窗口（无未提交事务）**，打开并整体执行 `setup.sql`。不必手工新建库。脚本首次需要 CREATE DATABASE 权限；初始化还需要沙盒建表与元数据权限。权限不足会报错停止，需管理员处理，不会降级到原数据库执行。
2. 脚本使用动态批次包含 `USE [Zhixing_Sandbox]` 与全部对象操作，没有 GO 分隔后继续执行的风险。执行完成后 SSMS 下拉框可能仍显示原库，因为动态 USE 的作用域只在该批次；结果中的 database_name 才是实际建表库。后续章节脚本均包含 USE 和身份检查。
3. 安装 Microsoft ODBC Driver 18 for SQL Server 和 Python 包：`py -m pip install pyodbc`。
4. 当前 PowerShell 会话设置连接串（实例名换成自己的；以下使用 Windows 身份验证）：

   ```powershell
   $env:SQLSERVER_CONNECTION_STRING = 'DRIVER={ODBC Driver 18 for SQL Server};SERVER=你的实例名;DATABASE=Zhixing_Sandbox;Trusted_Connection=yes;Encrypt=yes;TrustServerCertificate=no;'
   py main.py
   ```

   服务器证书须受信任，连接名须与证书匹配。认证或证书问题应按微软文档和实例配置排查；不要在代码中写密码，也不要为了通过检查而连接其他数据库。连接函数使用新连接、autocommit=False，关闭连接时释放资源。
5. 查看 `report.csv`（全部沙盒记录汇总）、`rejected.csv`（输入无效或文件内重复）和 `conflicts.csv`（与数据库同 ID 不同内容）。CSV 文件保存在程序目录；这些报告会更新，数据库已有行不会被覆盖。

## 新沙盒验收

setup.sql 已插入 5 条样本。原始 CSV 有 7 行，校验后有效 5、拒绝 2。原样导入时新增 0、相同跳过 5、冲突 0；重复运行结果不变。三事件为校园音乐节 3 条/45 赞、科技展 2 条/20 赞、读书会 0 条/0 赞。

1. 添加 id=7、event_id=2、likes=5 的记录：首次新增 1，科技展为 3 条/25 赞；第二次新增 0。
2. 修改已有 id=1 的 likes 为 99：产生冲突，数据库中的 12 保持不变。
3. 从 CSV 移除 id=2：数据库仍保留该记录；不会回到“文件快照”状态。
4. 只有表头的空文件或所有输入行均无效时：新增 0，已有数据库记录和报表内容保留。
5. 有其他额外记录的沙盒不应强行重置到样例总数；预期结果只适用于未改动样本。

## SQL 章节和测试

- `queries.sql`：汇总、分组前两名和无博文事件查询，带固定沙盒检查。
- `chapters/01_example.sql` 至 `16_example.sql` 与网站 16 章 SQL 示例一致；同编号 `_answer.sql` 是完整可执行参考答案。先执行 setup.sql；每个文件单独完整执行，不要把文件拼接到同一批次。查询需要 SELECT 权限，视图和索引例子需要相应 DDL 权限。
- 建表、索引、视图增加存在检查；视图使用独立动态批次。事务修改练习只操作临时表并回滚，不改变正式样本。
- 遇到人为改过的同名对象、旧兼容级别或权限不足，会安全报错；“静态审计通过”不代表所有环境 100% 零报错。
- 工程包含自动化测试与逐章审计记录 `SQL_AUDIT.md`。本轮没有连接实际 SQL Server；行为测试使用数据库替身，验证导入分支和拒绝/回滚逻辑，不能替代引擎集成测试。

## 数据与失败处理

CSV post_id 映射到 posts.id；id 和 likes 按 SQL int 范围验证，正文按 NVARCHAR(500) 的 UTF-16 单元长度验证；重复 id 保留首条有效记录。事件编号限制为样本 1、2、3。

数据库错误会回滚本批写入；导出 CSV 在提交后进行，不与数据库组成跨文件事务。导出失败时可重新运行，因为只新增写入不会造成重复或覆盖。数据库标记用于防止误操作，不是密码或安全认证机制。
