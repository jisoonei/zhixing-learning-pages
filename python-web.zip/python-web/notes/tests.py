from django.contrib.auth import get_user_model
from django.test import TestCase, Client
from django.urls import reverse
from .models import Topic, Entry

class OwnershipTests(TestCase):
    def setUp(self):
        User = get_user_model()
        self.a = User.objects.create_user('reader_a', password='test-password-938!')
        self.b = User.objects.create_user('reader_b', password='test-password-871!')
        self.topic = Topic.objects.create(title='私有主题', owner=self.a)
        self.entry = Entry.objects.create(topic=self.topic, text='原笔记')
    def test_anonymous_redirect(self):
        self.assertEqual(self.client.get('/').status_code, 302)
    def test_owner_access(self):
        self.client.force_login(self.a)
        self.assertContains(self.client.get(reverse('detail', args=[self.topic.pk])), '原笔记')
    def test_other_user_cannot_read(self):
        self.client.force_login(self.b)
        self.assertEqual(self.client.get(reverse('detail', args=[self.topic.pk])).status_code, 404)
        self.assertNotContains(self.client.get('/'), '私有主题')
    def test_other_user_cannot_write(self):
        self.client.force_login(self.b)
        self.assertEqual(self.client.post(reverse('edit_entry', args=[self.entry.pk]), {'text':'篡改'}).status_code, 404)
        self.assertEqual(self.client.post(reverse('new_entry', args=[self.topic.pk]), {'text':'注入'}).status_code, 404)
        self.entry.refresh_from_db()
        self.assertEqual(self.entry.text, '原笔记')
    def test_owner_is_server_assigned(self):
        self.client.force_login(self.b)
        self.client.post('/new/', {'title':'新主题', 'owner':self.a.pk})
        self.assertEqual(Topic.objects.get(title='新主题').owner, self.b)
    def test_empty_title_rejected(self):
        self.client.force_login(self.a)
        self.client.post('/new/', {'title':'   '})
        self.assertEqual(Topic.objects.count(), 1)
    def test_text_is_escaped(self):
        self.entry.text = '<script>alert(1)</script>'
        self.entry.save()
        self.client.force_login(self.a)
        response = self.client.get(reverse('detail', args=[self.topic.pk]))
        self.assertContains(response, '&lt;script&gt;')
        self.assertNotContains(response, '<script>')
    def test_csrf(self):
        client = Client(enforce_csrf_checks=True)
        client.force_login(self.a)
        self.assertEqual(client.post('/new/', {'title':'未经令牌'}).status_code, 403)
    def test_logout_requires_post(self):
        self.client.force_login(self.a)
        self.assertEqual(self.client.get('/accounts/logout/').status_code, 405)
        self.assertEqual(self.client.post('/accounts/logout/').status_code, 302)
    def test_register(self):
        response = self.client.post('/signup/', {'username':'new_reader', 'password1':'long-unique-7824!', 'password2':'long-unique-7824!'})
        self.assertEqual(response.status_code, 302)
        self.assertEqual(self.client.get('/').status_code, 200)
