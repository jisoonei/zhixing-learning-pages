from django.urls import path
from . import views
urlpatterns = [path('', views.index, name='index'), path('new/', views.new_topic, name='new_topic'),
    path('topics/<int:pk>/', views.detail, name='detail'),
    path('topics/<int:pk>/entry/', views.new_entry, name='new_entry'),
    path('entries/<int:pk>/edit/', views.edit_entry, name='edit_entry')]
