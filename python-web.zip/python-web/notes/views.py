from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import UserCreationForm
from django.shortcuts import render, redirect, get_object_or_404
from .models import Topic, Entry
from .forms import TopicForm, EntryForm

def signup(request):
    form = UserCreationForm(request.POST if request.method == 'POST' else None)
    if request.method == 'POST' and form.is_valid():
        login(request, form.save())
        return redirect('index')
    return render(request, 'form.html', {'form': form, 'title': '注册'})

@login_required
def index(request):
    topics = Topic.objects.filter(owner=request.user).order_by('-created_at', '-pk')
    return render(request, 'index.html', {'topics': topics})

@login_required
def detail(request, pk):
    topic = get_object_or_404(Topic, pk=pk, owner=request.user)
    entries = topic.entries.order_by('created_at', 'pk')
    return render(request, 'detail.html', {'topic': topic, 'entries': entries})

@login_required
def new_topic(request):
    form = TopicForm(request.POST if request.method == 'POST' else None)
    if request.method == 'POST' and form.is_valid():
        topic = form.save(commit=False)
        topic.owner = request.user
        topic.save()
        return redirect('detail', pk=topic.pk)
    return render(request, 'form.html', {'form': form, 'title': '新建主题'})

@login_required
def new_entry(request, pk):
    topic = get_object_or_404(Topic, pk=pk, owner=request.user)
    form = EntryForm(request.POST if request.method == 'POST' else None)
    if request.method == 'POST' and form.is_valid():
        entry = form.save(commit=False)
        entry.topic = topic
        entry.save()
        return redirect('detail', pk=topic.pk)
    return render(request, 'form.html', {'form': form, 'title': '新增笔记'})

@login_required
def edit_entry(request, pk):
    entry = get_object_or_404(Entry, pk=pk, topic__owner=request.user)
    form = EntryForm(request.POST if request.method == 'POST' else None, instance=entry)
    if request.method == 'POST' and form.is_valid():
        form.save()
        return redirect('detail', pk=entry.topic_id)
    return render(request, 'form.html', {'form': form, 'title': '修改笔记'})
